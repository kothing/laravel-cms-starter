<?php

namespace Star\LaravelModuleManager;

class LaravelModuleManager
{
    // Build your next great package.
}

# Usage

From your projects root folder in terminal run:

```php
composer require star/laravel-installer
```

Publish the packages views, config file, assets, and language files by running the following from your projects root folder:

```php
php artisan vendor:publish --tag=laravel-installer
```
